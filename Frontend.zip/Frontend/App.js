import React, { Component } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "./App.css";

import AddBook from "./components/AddBook";
import BookUpdate from "./components/BookUpdate";
import DisplayBooks from "./components/DsplyBk_fncCompt";
import DeleteBook from "./components/Delete_Book";

export default class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
          <center>
            <h2>On-Line Book Library using React</h2>
          </center>

          <br />

<nav className="navbar navbar-expand-lg navbar-dark bg-primary">
            <Link to="/" className="navbar-brand">
              <h4>Add a Book</h4>
            </Link>

            <Link to="/DisplayBooksF1" className="navbar-brand">
              <h4>Display All Books</h4>
            </Link>
          </nav>

          <br />

          <Routes>
            <Route path="/" element={<AddBook />} />
            <Route path="/edit/:id" element={<BookUpdate />} />
            <Route path="/Delete/:id" element={<DeleteBook />} />
            <Route path="/DisplayBooksF1" element={<DisplayBooks />} />
          </Routes>
        </div>
      </Router>
    );
  }
}
