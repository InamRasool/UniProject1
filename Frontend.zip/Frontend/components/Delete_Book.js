import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import DisplayData from "./DisplayData";

export default function DeleteBook() {
  const [state, setState] = useState([]);
  const { id } = useParams();
  const ranOnce = useRef(false);

  useEffect(() => {
    if (ranOnce.current) return; // avoids double delete in React 18 dev mode
    ranOnce.current = true;

    axios
      .post("http://localhost:5000/deleteBook/" + id)
      .then(() => axios.get("http://localhost:5000/allbooks"))
      .then((res) => setState(res.data))
      .catch((err) => console.log(err));
  }, [id]);

  return (
    <div>
      <DisplayData Books={state} />
    </div>
  );
}
