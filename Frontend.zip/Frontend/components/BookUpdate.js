import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function BookUpdate() {
  const BASE = "http://localhost:5000/";
  const { id } = useParams();

  const [state, setState] = useState({
    booktitle: "",
    author: "",
    formate: "",
    Topic: "",
    PubYear: 1990,
  });

  useEffect(() => {
    axios
      .get(BASE + "getbook/" + id)
      .then((res) => setState(res.data))
      .catch(() => alert("Failed to load book for editing."));
  }, [id]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setState((prev) => ({
      ...prev,
      [name]: type === "range" ? Number(value) : value,
    }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      booktitle: state.booktitle,
      PubYear: state.PubYear,
      author: state.author,
      Topic: state.Topic,
      formate: state.formate,
    };

    await axios.post(BASE + "updatebook/" + id, payload);
    alert("Book updated successfully.");
  };

  return (
    <div style={{ marginTop: 10 }}>
      <h3>Update Book</h3>

      <form onSubmit={onSubmit}>
        <div className="form-group">
          <label>Book Title:</label>
          <input
            className="form-control"
            type="text"
            name="booktitle"
            value={state.booktitle || ""}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Author:</label>
          <input
            className="form-control"
            type="text"
            name="author"
            value={state.author || ""}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Topic:</label>
          <select
            className="form-control"
            name="Topic"
            value={state.Topic || ""}
            onChange={handleChange}
          >
            <option value="">-- Select --</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Programming">Programming</option>
            <option value="AI">AI</option>
            <option value="Data Science">Data Science</option>
            <option value="Engineering">Engineering</option>
          </select>
        </div>

        <div className="form-group">
          <label>Format:</label>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="formate"
              value="Hard Copy"
              checked={state.formate === "Hard Copy"}
              onChange={handleChange}
            />
            <label className="form-check-label">Hard Copy</label>
          </div>

          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="formate"
              value="Electronic Copy"
              checked={state.formate === "Electronic Copy"}
              onChange={handleChange}
            />
            <label className="form-check-label">Electronic Copy</label>
          </div>
        </div>

        <div className="form-group">
          <label>Publication Year: {state.PubYear}</label>
          <input
            className="form-control"
            type="range"
            name="PubYear"
            min="1980"
            max="2025"
            value={state.PubYear}
            onChange={handleChange}
          />
        </div>

        <center>
          <button type="submit" className="btn btn-primary" style={{ marginTop: 10 }}>
            Update
          </button>
        </center>
      </form>
    </div>
  );
}
