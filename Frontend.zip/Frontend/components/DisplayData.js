import { Link } from "react-router-dom";

const ShowBooks = ({ TBooks }) => {
  if (!TBooks || TBooks.length === 0) return null;

  return TBooks.map((book) => (
    <tr key={book._id}>
      <td>{book.booktitle}</td>
      <td>{book.PubYear}</td>
      <td>{book.author}</td>
      <td>{book.Topic}</td>
      <td>{book.formate}</td>
      <td>
        <Link to={"/edit/" + book._id}>Edit</Link>
      </td>
      <td>
        <Link to={"/Delete/" + book._id}>Delete</Link>
      </td>
    </tr>
  ));
};

export default function DisplayData({ Books }) {
  if (!Books || Books.length === 0) return <h3>No Data Returned</h3>;

  return (
    <div>
      <h3>Book List</h3>

      <table className="table table-striped table-hover" style={{ marginTop: 20 }}>
        <thead>
          <tr>
            <th>Book Title</th>
            <th>Pub Year</th>
            <th>Author</th>
            <th>Subject</th>
            <th>Format</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>

        <tbody>
          <ShowBooks TBooks={Books} />
        </tbody>
      </table>
    </div>
  );
}
